document.addEventListener('DOMContentLoaded', () => {
    const display = document.getElementById('display');
    const buttonsContainer = document.querySelector('.calculator-buttons');
    const themeToggle = document.querySelector('.theme-toggle');

    let currentExpression = ""; // Stores the full expression
    let lastInput = ""; // Stores the last input to prevent invalid cases

    // Attach event listeners
    buttonsContainer.addEventListener('click', handleButtonClick);
    document.addEventListener('keydown', handleKeyPress);
    themeToggle.addEventListener('click', toggleTheme);

    function handleButtonClick(event) {
        if (event.target.tagName.toLowerCase() !== 'button') return;
        processInput(event.target.getAttribute('data-value'));
    }

    function handleKeyPress(event) {
        const keyMap = {
            "Enter": "=",
            "Escape": "clear",
            "/": "/",
            "*": "*",
            "-": "-",
            "+": "+",
            ".": ".",
        };

        if (!isNaN(event.key)) {
            processInput(event.key);
        } 
        else if (keyMap[event.key]) {
            processInput(keyMap[event.key]);
        }
    }

    function processInput(value) {
        if (value === "clear") {
            clearDisplay();
        } 
        else if (value === "=") {
            computeResult();
        } 
        else {
            updateDisplay(value);
        }
    }

    function updateDisplay(value) {
        // Prevent multiple decimal points in the same number
        if (value === "." && lastInput.includes(".")) return;

        // Prevent multiple operators in a row
        if ("+-*/".includes(value) && "+-*/".includes(lastInput)) return;

        // Update expression
        if (display.textContent === "0" && value !== ".") {
            currentExpression = value;
        } 
        else {
            currentExpression += value;
        }

        lastInput = value;
        display.textContent = currentExpression;
    }

    function computeResult() {
        try {
            if (currentExpression.includes("/0")) {
                throw new Error("Cannot divide by zero");
            }

            let result = eval(currentExpression);

            if (!isFinite(result)) {
                throw new Error("Math Error");
            }

            display.textContent = result;
            currentExpression = result.toString(); // Allow further calculations
        } 
        catch (error) {
            display.textContent = "Error";
            currentExpression = "0";
        }
    }

    function clearDisplay() {
        display.textContent = "0";
        currentExpression = "";
        lastInput = "";
    }

    function toggleTheme() {
        document.body.classList.toggle('light-mode');
        themeToggle.textContent = document.body.classList.contains('light-mode') ? "🌙" : "☀️";
    }
});
